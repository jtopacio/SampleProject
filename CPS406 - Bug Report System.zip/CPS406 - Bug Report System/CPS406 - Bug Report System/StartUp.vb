﻿Public Class StartUp

    Private Sub Login_Click(sender As Object, e As EventArgs) Handles Login.Click
        LoginPage.Show()
        Me.Close()
    End Sub

    Private Sub Register_Click(sender As Object, e As EventArgs) Handles Register.Click
        Registration.Show()
        Me.Close()
    End Sub
End Class