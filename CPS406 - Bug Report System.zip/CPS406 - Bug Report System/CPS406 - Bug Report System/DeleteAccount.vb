﻿Imports System.IO
Public Class DeleteAccount
    Dim reader As StreamReader
    Dim reader2 As StreamReader
    Dim filename As String = "Accounts.txt"
    Dim filename2 As String = "CurrentUser.txt"
    Private Sub Cancel_Click(sender As Object, e As EventArgs) Handles Cancel.Click
        Me.Close()
    End Sub

    Private Sub DeleteAcc_Click(sender As Object, e As EventArgs) Handles DeleteAcc.Click
        Dim userData As String = ""
        Dim passData As String = ""
        Dim currentUser As String = ""
        Dim currentPass As String = ""
        Dim accountList As New List(Of KeyValuePair(Of String, String))
        Dim newAccountList As New List(Of KeyValuePair(Of String, String))
        Dim accountInUse As New List(Of KeyValuePair(Of String, String))

        reader = File.OpenText(filename)
        Do Until reader.EndOfStream
            userData = reader.ReadLine()
            passData = reader.ReadLine()
            accountList.Add(New KeyValuePair(Of String, String)(passData, userData))
        Loop
        reader.Close()

        reader2 = File.OpenText(filename2)
        Do Until reader2.EndOfStream
            currentUser = reader2.ReadLine()
            currentPass = reader2.ReadLine()
            accountInUse.Add(New KeyValuePair(Of String, String)(currentPass, currentUser))
        Loop
        reader2.Close()

        Dim userLog = Username.Text
        Dim passLog = Password.Text
        Dim accountToBeDeleted As KeyValuePair(Of String, String) = New KeyValuePair(Of String, String)(passLog, userLog)

        If Not accountInUse.Contains(accountToBeDeleted) Then
            MsgBox("Incorrect Username/Password!")
        End If

        If accountInUse.Contains(accountToBeDeleted) Then
            Dim writer As New StreamWriter("Accounts.txt", False)
            For Each account As KeyValuePair(Of String, String) In accountList
                If Not account.Value = accountToBeDeleted.Value And Not account.Key = accountToBeDeleted.Key Then
                    newAccountList.Add(New KeyValuePair(Of String, String)(account.Key, account.Value))
                End If
            Next
            For Each newAcc As KeyValuePair(Of String, String) In newAccountList
                writer.WriteLine(newAcc.Value)
                writer.WriteLine(newAcc.Key)
            Next
            writer.Close()
            MsgBox("Account Deleted! Logging out...")
            MainPage.Close()
            StartUp.Show()
            Me.Close()
        End If
    End Sub
End Class