﻿Imports System.IO 'Ensure you import the System.IO Namespace
Public Class BugReportList

    Private Sub BugReportList_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        For Each i As String In Directory.GetFiles("Bug Reports\") 'the GetFiles method returns an array string of all the files in that directory; hence we are using a for each loop here
            If (Path.GetFileName(i)) <> "Accounts.txt" And (Path.GetFileName(i)) <> "CurrentUser.txt" Then
                ListView1.Items.Add(Path.GetFileName(i))
            End If

        Next

    End Sub

    Private Sub BR_list_close_Click(sender As Object, e As EventArgs) Handles BR_list_close.Click
        Me.Close()
    End Sub


    Private Sub BR_list_load_Click(sender As Object, e As EventArgs) Handles BR_list_load.Click
        For Each file As ListViewItem In ListView1.Items
            Dim filePath As String = "Bug Reports\" + file.Text
            Dim lines() As String = IO.File.ReadAllLines(filePath)
            If file.Selected = True Then
                    'Process.Start(filePath)
                    For lngPosition = LBound(lines) To UBound(lines)
                        If lngPosition = 0 Then
                            BR_loaded.Text = "Username: "
                        End If
                        If lngPosition = 1 Then
                            BR_loaded.Text = BR_loaded.Text + "Report:" & vbCrLf
                        End If
                        BR_loaded.Text = BR_loaded.Text + lines(lngPosition) & vbCrLf
                    Next lngPosition
            End If
        Next
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        BR_loaded.Text = ""
    End Sub
End Class
