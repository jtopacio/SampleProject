﻿Imports System.IO
Public Class BRList

    Private Sub ClosePage_Click(sender As Object, e As EventArgs) Handles ClosePage.Click
        Me.Close()
    End Sub

    Private Sub DisplayBR_Click(sender As Object, e As EventArgs) Handles DisplayBR.Click
        For Each foundFile As String In My.Computer.FileSystem.GetFiles("Bug Reports\")
            Dim longFileName As String = foundFile
            Dim trimFileName As String = Replace(foundFile, "Bug Reports\", "")
            Dim trimmedFileName As String = Replace(trimFileName, ".txt", "")
            BugReportList.Items.Add(trimmedFileName)
        Next

        Dim butt As Button = DirectCast(sender, Button)
        butt.Enabled = False
    End Sub

    Private Sub OpenBR_Click(sender As Object, e As EventArgs) Handles OpenBR.Click
        Dim reportAuthor As String = BR_Author.Text
        If Dir("Bug Reports\" + reportAuthor + " - " + BR_Name.Text + ".txt") <> "" Then
            Dim lines() As String = IO.File.ReadAllLines("Bug Reports\" + reportAuthor + " - " + BR_Name.Text + ".txt")
            Dim count As Single = 0
            Dim final_count As Single = 0
            Dim temp As String = "blank"
            Dim temp2 As String = "blank"
            Dim found As Single = 0
            BR_Info.Text = ""
            For lngPosition = LBound(lines) To UBound(lines)
                If lngPosition = 0 Then
                    reportAuthor = lines(lngPosition)
                    lngPosition = lngPosition + 1
                End If
                BR_Info.Text = BR_Info.Text + lines(lngPosition)
            Next lngPosition


        Else : MsgBox("Bug Report Does Not Exist")
        End If


    End Sub

    Private Sub BR_Name_TextChanged(sender As Object, e As EventArgs) Handles BR_Name.TextChanged
        BR_Info.Text = ""
    End Sub

    Private Sub ClearBR_Click(sender As Object, e As EventArgs) Handles ClearBR.Click
        BR_Info.Text = ""
        BR_Name.Text = ""
        BR_Author.Text = ""
    End Sub
End Class