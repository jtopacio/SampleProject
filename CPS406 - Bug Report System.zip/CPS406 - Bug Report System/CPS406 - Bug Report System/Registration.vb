﻿Imports System.IO
Public Class Registration
    Dim reader As StreamReader
    Dim filename As String = "Accounts.txt"
    Dim securePassLength As Integer = 6


    Private Sub CreateAcc_Click(sender As Object, e As EventArgs) Handles CreateAcc.Click
        Dim userData As String = ""
        Dim list As New List(Of String)
        reader = File.OpenText(filename)
        Do Until reader.EndOfStream()
            userData = reader.ReadLine()
            list.Add(userData)
        Loop
        reader.Close()

        
        Dim userLog = Username.Text
        Dim passLog = Password.Text

        If String.IsNullOrWhiteSpace(userLog) Or String.IsNullOrWhiteSpace(passLog) Or String.IsNullOrWhiteSpace(Confirm.Text) Then
            MsgBox("Error: Missing Information!")
        ElseIf CheckForAlphaCharacters(userLog) <> True Then
            MsgBox("Username contains invalid characters!")
        ElseIf Not passLog = Confirm.Text Then
            MsgBox("Error: Password not confirmed, try again!")
        ElseIf Not passLog.Length >= securePassLength Then
            MsgBox("Error: Password is not at secure length!")
        ElseIf list.Contains(userLog) Then
            MsgBox("Error: Username taken!")
        End If

        If Not list.Contains(userLog) And Not String.IsNullOrWhiteSpace(userLog) And passLog = Confirm.Text And Not String.IsNullOrWhiteSpace(passLog) And Not String.IsNullOrWhiteSpace(Confirm.Text) And passLog.Length >= securePassLength And CheckForAlphaCharacters(userLog) = True Then
            Dim writer As New StreamWriter("Accounts.txt", True)
            Dim writer2 As New StreamWriter("CurrentUser.txt", False)
            writer.WriteLine(userLog)
            writer.WriteLine(passLog)
            writer.Close()
            writer2.WriteLine(userLog)
            writer2.WriteLine(passLog)
            writer2.Close()
            MsgBox("Account Created! Logging in...")
            MainPage.Show()
            Me.Close()

        End If

    End Sub

    Private Sub Confirm_TextChanged(sender As Object, e As EventArgs) Handles Confirm.TextChanged
        If Not Confirm.Text = Password.Text Then
            Confirmation.Text = "Passwords do not match"
        Else
            Confirmation.Text = ""
        End If
    End Sub

    Private Sub Cancel_Click(sender As Object, e As EventArgs) Handles Cancel.Click
        StartUp.Show()
        Me.Close()
    End Sub

    Private Sub Password_TextChanged(sender As Object, e As EventArgs) Handles Password.TextChanged
        If Not Confirm.Text = Password.Text Then
            Confirmation.Text = "Passwords do not match"
        Else
            Confirmation.Text = ""
        End If

        If Password.Text.Length >= securePassLength Then
            SecurePass.Text = "Password is at secure length"
        ElseIf Password.Text.Length >= 1 And Password.Text.Length < securePassLength Then
            SecurePass.Text = "Password is not at secure length"
        ElseIf Password.Text.Length = 0 Then
            SecurePass.Text = ""
        End If
    End Sub

    Function CheckForAlphaCharacters(ByVal StringToCheck As String)
        For i = 0 To StringToCheck.Length - 1
            If Not Char.IsLetter(StringToCheck.Chars(i)) And Not Char.IsNumber(StringToCheck.Chars(i)) Then
                Return False
            End If

        Next


        Return True 'Return true if all elements are characters
    End Function


End Class