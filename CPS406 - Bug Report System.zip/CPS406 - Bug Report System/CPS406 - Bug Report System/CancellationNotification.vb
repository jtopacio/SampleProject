﻿Imports System.Web
Imports System.IO
Imports System.Net.Mail


Public Class CancellationNotification
    Dim email As New MailMessage
    Dim smtp As New SmtpClient
    Dim mail As System.Net.Mail.MailAddress

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If String.IsNullOrWhiteSpace(TextBox5.Text) Then
            MsgBox("Error: Invalid To email addresses!")
        Else
            email.From = New MailAddress("cps406.brs@gmail.com")
            email.Subject = TextBox6.Text
            email.Body = TextBox4.Text
            email.To.Add(TextBox5.Text)
            smtp.EnableSsl = True
            smtp.Port = 587
            smtp.Host = "smtp.gmail.com"
            smtp.Credentials = New Net.NetworkCredential("cps406.brs@gmail.com", "toronto95")
            smtp.Send(email)
            MsgBox("This email has been sent.")
            Me.Close()
        End If

    End Sub
End Class
