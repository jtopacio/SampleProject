﻿Imports System.IO
Public Class LoginPage
    Dim reader As StreamReader
    Dim filename As String = "Accounts.txt"

    Private Sub CreateAccount_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles CreateAccount.LinkClicked
        Registration.Show()
        Me.Close()
    End Sub

    Private Sub LoginUser_Click(sender As Object, e As EventArgs) Handles LoginUser.Click
        Dim userData As String = ""
        Dim passData As String = ""
        Dim accounts As New List(Of KeyValuePair(Of String, String))
        reader = File.OpenText(filename)
        Do Until reader.EndOfStream

            userData = reader.ReadLine()
            passData = reader.ReadLine()
            accounts.Add(New KeyValuePair(Of String, String)(passData, userData))
        Loop
        reader.Close()

        Dim userLog = Username.Text
        Dim passLog = Password.Text
        Dim account As KeyValuePair(Of String, String) = New KeyValuePair(Of String, String)(passLog, userLog)

        If String.IsNullOrWhiteSpace(Username.Text) Or String.IsNullOrWhiteSpace(Password.Text) Or Not accounts.Contains(account) Then
            MsgBox("Invalid Username/Password!")
        End If

        If accounts.Contains(account) And Not String.IsNullOrWhiteSpace(userLog) And Not String.IsNullOrWhiteSpace(passLog) Then
            Dim writer As New StreamWriter("CurrentUser.txt", False)
            writer.WriteLine(account.Value)
            writer.WriteLine(account.Key)
            writer.Close()
            MsgBox("Logging in...")
            MainPage.Show()
            Me.Close()
        End If
    End Sub

    Private Sub CancelLogin_Click(sender As Object, e As EventArgs) Handles CancelLogin.Click
        StartUp.Show()
        Me.Close()
    End Sub

    Private Sub ForgotPass_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles ForgotPass.LinkClicked
        RecoverPass.Show()
    End Sub

End Class