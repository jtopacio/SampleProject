﻿Imports System.Web
Imports System.IO
Imports System.Net.Mail


Public Class RecoverPass
    Dim email As New MailMessage
    Dim smtp As New SmtpClient
    Dim mail As System.Net.Mail.MailAddress
    Dim msg As New Attachment("CurrentUser.txt")

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If String.IsNullOrWhiteSpace(TextBox5.Text) Then
            MsgBox("Error: Invalid email address in To: ")
        Else
            email.From = New MailAddress("cps406.brs@gmail.com")
            email.Subject = "Password Forgotten"
            email.Body = "You have requested your password for your Bug Report Account. Your username and Password are attached to this email, in the file called CurrentUser.txt."
            email.To.Add(TextBox5.Text)
            smtp.EnableSsl = True
            smtp.Port = 587
            smtp.Host = "smtp.gmail.com"
            smtp.Credentials = New Net.NetworkCredential("cps406.brs@gmail.com", "toronto95")
            email.Attachments.Add(msg)
            Try
                smtp.Send(email)
                MsgBox("This email has been sent.")
            Catch ex As Exception
                MsgBox("This email has failed.")
            End Try
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
End Class
