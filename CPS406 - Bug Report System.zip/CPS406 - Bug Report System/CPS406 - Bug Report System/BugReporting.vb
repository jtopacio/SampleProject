﻿Imports System
Imports System.IO
Imports System.Text
Public Class BugReporting

    Dim currentUserFile() As String = IO.File.ReadAllLines("CurrentUser.txt")
    Dim currentUser As String = currentUserFile(0)
    Dim passState As Integer = 0


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        BR_username.Text = currentUser
        BR_edit_author.Text = currentUser
        BR_cancel_author.Text = currentUser
    End Sub

    Private Sub BR_submit_Click(sender As Object, e As EventArgs) Handles BR_submit.Click


        If BR_desc.Text <> "" And BR_reason.Text <> "" Then
            passState = 1
        Else
            passState = 0
            If BR_desc.Text = "" And BR_reason.Text = "" Then
                MsgBox("Error: No information given! Please enter a bug report ID and description!")
            Else
                If BR_reason.Text = "" Then
                    MsgBox("Error: Bug Report requires an ID!")
                End If
                If BR_desc.Text = "" Then
                    MsgBox("Error: Bug Report requires a description!")
                End If
            End If
        End If

        If BR_desc.Text <> "" Then
            If BR_desc.Text.Length > 50 Then
                passState = 1
            Else
                MsgBox("Error: Description needs to be at least 50 characters long!")
                passState = 0
            End If
        End If



        If passState = 1 Then
            Dim path As String = "Bug Reports\" + currentUser + " - " + BR_reason.Text + ".txt"
            If Dir(path) = "" Then
                Dim fs As FileStream = File.Create(path)
                fs.Close()
                Dim objWriter As New System.IO.StreamWriter(path, False)
                objWriter.WriteLine(BR_username.Text & vbNewLine & BR_desc.Text)
                objWriter.Close()
                MsgBox("Bug Report Submitted!")
                BR_reason.Text = ""
                BR_desc.Text = ""
            Else
                MsgBox("A Report With That ID Already Exists!")
            End If
            
        End If

    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If Dir("Bug Reports\" + BR_edit_author.Text + " - " + BR_edit.Text + ".txt") <> "" Then
            Dim lines() As String = IO.File.ReadAllLines("Bug Reports\" + BR_edit_author.Text + " - " + BR_edit.Text + ".txt")
            Dim Lookfor As String = currentUser
            If String.Compare(lines(0), Lookfor, True) = 0 Then
                BR_reason.Text = BR_edit.Text
                Dim count As Single = 0
                Dim final_count As Single = 0
                Dim temp As String = "blank"
                Dim temp2 As String = "blank"
                Dim found As Single = 0
                BR_desc.Text = ""
                For lngPosition = LBound(lines) To UBound(lines)
                    If lngPosition = 0 Then
                        BR_username.Text = lines(lngPosition)
                        lngPosition = lngPosition + 1
                    End If
                    BR_desc.Text = BR_desc.Text + lines(lngPosition)
                Next lngPosition
            Else : MsgBox("Error: Current user is not the author of this report!")
            End If
            'If Findstring.Contains(Lookfor) Then

        Else
            MsgBox("Error: Bug Report Does Not Exist!")
        End If
        'BR_edit_author.Text = ""
        BR_edit.Text = ""
    End Sub


    Private Sub BR_close_Click(sender As Object, e As EventArgs) Handles BR_close.Click
        If Dir("Bug Reports\" + BR_cancel_author.Text + " - " + BR_cancel_ID.Text + ".txt") <> "" Then
            'MsgBox("File exists")
            Dim lines() As String = IO.File.ReadAllLines("Bug Reports\" + BR_cancel_author.Text + " - " + BR_cancel_ID.Text + ".txt")
            Dim Lookfor As String = currentUser
            Dim count As Single = 0
            Dim final_count As Single = 0
            Dim temp As String = "blank"
            Dim temp2 As String = "blank"
            Dim found As Single = 0
            BR_desc.Text = ""
            If String.Compare(lines(0), Lookfor, True) = 0 Then
                Kill("Bug Reports\" + currentUser + " - " + BR_cancel_ID.Text + ".txt")
                MsgBox("Bug Report Closed")
                CancellationNotification.Show()
                Me.Close()
            Else : MsgBox("Error: Current user is not the author of this report!")
            End If
        Else
            MsgBox("Error: Bug Report Does Not Exist!")
        End If
        BR_cancel_author.Text = ""
        BR_cancel_ID.Text = ""


    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        EmailNotification.Show()
    End Sub

    Private Sub ClosePage_Click(sender As Object, e As EventArgs) Handles ClosePage.Click
        Me.Close()
    End Sub

    Private Sub OpenBRList_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles OpenBRList.LinkClicked
        BugReportList.Show()
    End Sub

    
End Class
