﻿
Public Class MainPage

    Private Sub DelAccToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DelAccToolStripMenuItem.Click
        DeleteAccount.Show()
    End Sub

    Private Sub ChangePasswordToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ChangePasswordToolStripMenuItem.Click
        ChangePass.Show()
    End Sub

    Private Sub BugReports_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles BugReports.LinkClicked
        BugReporting.Show()
    End Sub

    Private Sub LogOutToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles LogOutToolStripMenuItem1.Click
        StartUp.Show()
        Me.Close()
    End Sub

    Private Sub SeeBR_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles SeeBR.LinkClicked
        BugReportList.Show()
    End Sub
End Class
