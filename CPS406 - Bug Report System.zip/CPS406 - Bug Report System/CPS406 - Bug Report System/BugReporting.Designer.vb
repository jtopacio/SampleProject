﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class BugReporting
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(BugReporting))
        Me.BR_reason = New System.Windows.Forms.TextBox()
        Me.BR_desc = New System.Windows.Forms.TextBox()
        Me.Header = New System.Windows.Forms.Label()
        Me.BR_submit = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.BR_edit = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.BR_username = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.BR_cancel_ID = New System.Windows.Forms.TextBox()
        Me.BR_cancel_author = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.BR_close = New System.Windows.Forms.Button()
        Me.BR_edit_author = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.OpenBRList = New System.Windows.Forms.LinkLabel()
        Me.ClosePage = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BR_reason
        '
        Me.BR_reason.Location = New System.Drawing.Point(174, 44)
        Me.BR_reason.Name = "BR_reason"
        Me.BR_reason.Size = New System.Drawing.Size(118, 20)
        Me.BR_reason.TabIndex = 0
        '
        'BR_desc
        '
        Me.BR_desc.Location = New System.Drawing.Point(174, 66)
        Me.BR_desc.Multiline = True
        Me.BR_desc.Name = "BR_desc"
        Me.BR_desc.Size = New System.Drawing.Size(337, 173)
        Me.BR_desc.TabIndex = 1
        '
        'Header
        '
        Me.Header.AutoSize = True
        Me.Header.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Header.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Header.Location = New System.Drawing.Point(262, 25)
        Me.Header.Name = "Header"
        Me.Header.Size = New System.Drawing.Size(292, 37)
        Me.Header.TabIndex = 2
        Me.Header.Text = "Bug Report System"
        Me.Header.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'BR_submit
        '
        Me.BR_submit.Location = New System.Drawing.Point(174, 245)
        Me.BR_submit.Name = "BR_submit"
        Me.BR_submit.Size = New System.Drawing.Size(118, 23)
        Me.BR_submit.TabIndex = 3
        Me.BR_submit.Text = "Submit Bug Report"
        Me.BR_submit.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(312, 47)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(137, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Bug Report ID - Description"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(517, 69)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(215, 104)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = resources.GetString("Label2.Text")
        '
        'BR_edit
        '
        Me.BR_edit.Location = New System.Drawing.Point(162, 358)
        Me.BR_edit.Name = "BR_edit"
        Me.BR_edit.Size = New System.Drawing.Size(100, 20)
        Me.BR_edit.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(120, 298)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(189, 26)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Already Have An Existing Bug Report?" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Enter The ID number below."
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(162, 384)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(100, 23)
        Me.Button1.TabIndex = 8
        Me.Button1.Text = "Load Report"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'BR_username
        '
        Me.BR_username.BackColor = System.Drawing.SystemColors.Window
        Me.BR_username.Location = New System.Drawing.Point(174, 21)
        Me.BR_username.Name = "BR_username"
        Me.BR_username.ReadOnly = True
        Me.BR_username.Size = New System.Drawing.Size(118, 20)
        Me.BR_username.TabIndex = 9
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(312, 24)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(55, 13)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Username"
        '
        'BR_cancel_ID
        '
        Me.BR_cancel_ID.Location = New System.Drawing.Point(467, 355)
        Me.BR_cancel_ID.Name = "BR_cancel_ID"
        Me.BR_cancel_ID.Size = New System.Drawing.Size(100, 20)
        Me.BR_cancel_ID.TabIndex = 11
        '
        'BR_cancel_author
        '
        Me.BR_cancel_author.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.BR_cancel_author.Location = New System.Drawing.Point(467, 329)
        Me.BR_cancel_author.Name = "BR_cancel_author"
        Me.BR_cancel_author.ReadOnly = True
        Me.BR_cancel_author.Size = New System.Drawing.Size(100, 20)
        Me.BR_cancel_author.TabIndex = 12
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(416, 298)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(195, 26)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "Looking to close a previously submitted " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "bug report?"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(573, 332)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(73, 13)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "Report Author"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(573, 358)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(137, 13)
        Me.Label7.TabIndex = 15
        Me.Label7.Text = "Bug Report ID - Description"
        '
        'BR_close
        '
        Me.BR_close.Location = New System.Drawing.Point(467, 381)
        Me.BR_close.Name = "BR_close"
        Me.BR_close.Size = New System.Drawing.Size(100, 23)
        Me.BR_close.TabIndex = 16
        Me.BR_close.Text = "Close Report"
        Me.BR_close.UseVisualStyleBackColor = True
        '
        'BR_edit_author
        '
        Me.BR_edit_author.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.BR_edit_author.Location = New System.Drawing.Point(162, 332)
        Me.BR_edit_author.Name = "BR_edit_author"
        Me.BR_edit_author.ReadOnly = True
        Me.BR_edit_author.Size = New System.Drawing.Size(100, 20)
        Me.BR_edit_author.TabIndex = 17
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(16, 362)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(140, 13)
        Me.Label8.TabIndex = 18
        Me.Label8.Text = " Bug Report ID - Description"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(83, 336)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(73, 13)
        Me.Label9.TabIndex = 19
        Me.Label9.Text = "Report Author"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(9, 486)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(113, 29)
        Me.Button2.TabIndex = 20
        Me.Button2.Text = "Send Email"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(6, 470)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(454, 13)
        Me.Label10.TabIndex = 21
        Me.Label10.Text = "If there are any changes made to a Bug Report, please send a notification to the " & _
    "relevant users"
        '
        'GroupBox1
        '
        Me.GroupBox1.AutoSize = True
        Me.GroupBox1.BackColor = System.Drawing.SystemColors.Control
        Me.GroupBox1.Controls.Add(Me.OpenBRList)
        Me.GroupBox1.Controls.Add(Me.ClosePage)
        Me.GroupBox1.Controls.Add(Me.BR_username)
        Me.GroupBox1.Controls.Add(Me.BR_close)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.BR_cancel_ID)
        Me.GroupBox1.Controls.Add(Me.BR_cancel_author)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.BR_reason)
        Me.GroupBox1.Controls.Add(Me.BR_edit_author)
        Me.GroupBox1.Controls.Add(Me.Button2)
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.BR_desc)
        Me.GroupBox1.Controls.Add(Me.BR_submit)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.BR_edit)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 112)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(760, 537)
        Me.GroupBox1.TabIndex = 22
        Me.GroupBox1.TabStop = False
        '
        'OpenBRList
        '
        Me.OpenBRList.AutoSize = True
        Me.OpenBRList.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OpenBRList.Location = New System.Drawing.Point(254, 419)
        Me.OpenBRList.Name = "OpenBRList"
        Me.OpenBRList.Size = New System.Drawing.Size(218, 15)
        Me.OpenBRList.TabIndex = 23
        Me.OpenBRList.TabStop = True
        Me.OpenBRList.Text = "*Click here to see the list of bug reports"
        '
        'ClosePage
        '
        Me.ClosePage.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ClosePage.Location = New System.Drawing.Point(671, 485)
        Me.ClosePage.Name = "ClosePage"
        Me.ClosePage.Size = New System.Drawing.Size(83, 29)
        Me.ClosePage.TabIndex = 22
        Me.ClosePage.Text = "Close"
        Me.ClosePage.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.Color.Red
        Me.Label11.Location = New System.Drawing.Point(-13, 80)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(813, 10)
        Me.Label11.TabIndex = 23
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.InitialImage = Nothing
        Me.PictureBox1.Location = New System.Drawing.Point(93, 14)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(57, 63)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox1.TabIndex = 24
        Me.PictureBox1.TabStop = False
        '
        'BugReporting
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.ClientSize = New System.Drawing.Size(784, 661)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Header)
        Me.Name = "BugReporting"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "CPS 406"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BR_reason As System.Windows.Forms.TextBox
    Friend WithEvents BR_desc As System.Windows.Forms.TextBox
    Friend WithEvents Header As System.Windows.Forms.Label
    Friend WithEvents BR_submit As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents BR_edit As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents BR_username As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents BR_cancel_ID As System.Windows.Forms.TextBox
    Friend WithEvents BR_cancel_author As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents BR_close As System.Windows.Forms.Button
    Friend WithEvents BR_edit_author As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents ClosePage As System.Windows.Forms.Button
    Friend WithEvents OpenBRList As System.Windows.Forms.LinkLabel

End Class
