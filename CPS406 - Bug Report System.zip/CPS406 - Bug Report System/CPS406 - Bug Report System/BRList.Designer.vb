﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class BRList
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(BRList))
        Me.BugReportList = New System.Windows.Forms.ListBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.DisplayBR = New System.Windows.Forms.Button()
        Me.ClosePage = New System.Windows.Forms.Button()
        Me.OpenBR = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.BR_Info = New System.Windows.Forms.TextBox()
        Me.BR_Name = New System.Windows.Forms.TextBox()
        Me.BR_Author = New System.Windows.Forms.TextBox()
        Me.ClearBR = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Header = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'BugReportList
        '
        Me.BugReportList.FormattingEnabled = True
        Me.BugReportList.Location = New System.Drawing.Point(30, 32)
        Me.BugReportList.Name = "BugReportList"
        Me.BugReportList.Size = New System.Drawing.Size(195, 277)
        Me.BugReportList.TabIndex = 0
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.SystemColors.Control
        Me.GroupBox1.Controls.Add(Me.BugReportList)
        Me.GroupBox1.Location = New System.Drawing.Point(34, 161)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(260, 336)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        '
        'DisplayBR
        '
        Me.DisplayBR.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DisplayBR.Location = New System.Drawing.Point(64, 528)
        Me.DisplayBR.Name = "DisplayBR"
        Me.DisplayBR.Size = New System.Drawing.Size(184, 48)
        Me.DisplayBR.TabIndex = 2
        Me.DisplayBR.Text = "Display Bug Reports"
        Me.DisplayBR.UseVisualStyleBackColor = True
        '
        'ClosePage
        '
        Me.ClosePage.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ClosePage.Location = New System.Drawing.Point(660, 608)
        Me.ClosePage.Name = "ClosePage"
        Me.ClosePage.Size = New System.Drawing.Size(84, 31)
        Me.ClosePage.TabIndex = 3
        Me.ClosePage.Text = "Close Page"
        Me.ClosePage.UseVisualStyleBackColor = True
        '
        'OpenBR
        '
        Me.OpenBR.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OpenBR.Location = New System.Drawing.Point(326, 528)
        Me.OpenBR.Name = "OpenBR"
        Me.OpenBR.Size = New System.Drawing.Size(184, 48)
        Me.OpenBR.TabIndex = 4
        Me.OpenBR.Text = "Open Bug Report"
        Me.OpenBR.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.SystemColors.Control
        Me.GroupBox2.Controls.Add(Me.BR_Info)
        Me.GroupBox2.Location = New System.Drawing.Point(326, 212)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(418, 285)
        Me.GroupBox2.TabIndex = 5
        Me.GroupBox2.TabStop = False
        '
        'BR_Info
        '
        Me.BR_Info.BackColor = System.Drawing.SystemColors.Window
        Me.BR_Info.Location = New System.Drawing.Point(20, 19)
        Me.BR_Info.Multiline = True
        Me.BR_Info.Name = "BR_Info"
        Me.BR_Info.ReadOnly = True
        Me.BR_Info.Size = New System.Drawing.Size(379, 239)
        Me.BR_Info.TabIndex = 0
        '
        'BR_Name
        '
        Me.BR_Name.Location = New System.Drawing.Point(180, 41)
        Me.BR_Name.Name = "BR_Name"
        Me.BR_Name.Size = New System.Drawing.Size(160, 20)
        Me.BR_Name.TabIndex = 6
        '
        'BR_Author
        '
        Me.BR_Author.Location = New System.Drawing.Point(180, 13)
        Me.BR_Author.Name = "BR_Author"
        Me.BR_Author.Size = New System.Drawing.Size(160, 20)
        Me.BR_Author.TabIndex = 7
        '
        'ClearBR
        '
        Me.ClearBR.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ClearBR.Location = New System.Drawing.Point(560, 528)
        Me.ClearBR.Name = "ClearBR"
        Me.ClearBR.Size = New System.Drawing.Size(184, 48)
        Me.ClearBR.TabIndex = 8
        Me.ClearBR.Text = "Clear"
        Me.ClearBR.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(18, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(76, 13)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "Report Author:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(18, 44)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(140, 13)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "Bug Report ID - Description:"
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.Color.Red
        Me.Label11.Location = New System.Drawing.Point(-13, 80)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(813, 10)
        Me.Label11.TabIndex = 24
        '
        'Header
        '
        Me.Header.AutoSize = True
        Me.Header.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Header.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Header.Location = New System.Drawing.Point(262, 25)
        Me.Header.Name = "Header"
        Me.Header.Size = New System.Drawing.Size(292, 37)
        Me.Header.TabIndex = 25
        Me.Header.Text = "Bug Report System"
        Me.Header.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.InitialImage = Nothing
        Me.PictureBox1.Location = New System.Drawing.Point(93, 14)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(57, 63)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox1.TabIndex = 26
        Me.PictureBox1.TabStop = False
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.SystemColors.Control
        Me.GroupBox3.Controls.Add(Me.Label1)
        Me.GroupBox3.Controls.Add(Me.BR_Name)
        Me.GroupBox3.Controls.Add(Me.BR_Author)
        Me.GroupBox3.Controls.Add(Me.Label2)
        Me.GroupBox3.Location = New System.Drawing.Point(346, 132)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(352, 74)
        Me.GroupBox3.TabIndex = 27
        Me.GroupBox3.TabStop = False
        '
        'BRList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.ClientSize = New System.Drawing.Size(784, 661)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Header)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.ClearBR)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.OpenBR)
        Me.Controls.Add(Me.ClosePage)
        Me.Controls.Add(Me.DisplayBR)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "BRList"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "CPS 406"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BugReportList As System.Windows.Forms.ListBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents DisplayBR As System.Windows.Forms.Button
    Friend WithEvents ClosePage As System.Windows.Forms.Button
    Friend WithEvents OpenBR As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents BR_Name As System.Windows.Forms.TextBox
    Friend WithEvents BR_Info As System.Windows.Forms.TextBox
    Friend WithEvents BR_Author As System.Windows.Forms.TextBox
    Friend WithEvents ClearBR As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Header As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
End Class
