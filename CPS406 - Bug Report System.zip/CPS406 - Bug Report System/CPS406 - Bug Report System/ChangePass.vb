﻿Imports System.IO
Public Class ChangePass
    Dim reader As StreamReader
    Dim reader2 As StreamReader
    Dim filename As String = "Accounts.txt"
    Dim filename2 As String = "CurrentUser.txt"
    Dim securePassLength As Integer = 6
    Private Sub Cancel_Click(sender As Object, e As EventArgs) Handles Cancel.Click
        Me.Close()
    End Sub

    Private Sub PassChange_Click(sender As Object, e As EventArgs) Handles PassChange.Click
        Dim userData As String = ""
        Dim passData As String = ""
        Dim currentUser As String = ""
        Dim currentPass As String = ""
        Dim accountList As New List(Of KeyValuePair(Of String, String))
        Dim newAccountList As New List(Of KeyValuePair(Of String, String))
        Dim accountInUse As New List(Of KeyValuePair(Of String, String))

        reader = File.OpenText(filename)
        Do Until reader.EndOfStream
            userData = reader.ReadLine()
            passData = reader.ReadLine()
            accountList.Add(New KeyValuePair(Of String, String)(passData, userData))
        Loop
        reader.Close()

        reader2 = File.OpenText(filename2)
        Do Until reader2.EndOfStream
            currentUser = reader2.ReadLine()
            currentPass = reader2.ReadLine()
            accountInUse.Add(New KeyValuePair(Of String, String)(currentPass, currentUser))
        Loop
        reader2.Close()

        Dim userLog = Username.Text
        Dim passLog = OldPassword.Text
        Dim oldAccount As KeyValuePair(Of String, String) = New KeyValuePair(Of String, String)(passLog, userLog)
        Dim newAccount As KeyValuePair(Of String, String) = New KeyValuePair(Of String, String)(Newpass.Text, userLog)

        If String.IsNullOrWhiteSpace(userLog) Or String.IsNullOrWhiteSpace(passLog) Or String.IsNullOrWhiteSpace(Newpass.Text) Or String.IsNullOrWhiteSpace(ConfirmNewpass.Text) Then
            MsgBox("Error: Missing Information!")
        ElseIf Not accountInUse.Contains(oldAccount) Then
            MsgBox("Error: Incorrect Username/Current Password!")
        ElseIf Newpass.Text = oldAccount.Key And Not String.IsNullOrWhiteSpace(Newpass.Text) And Not String.IsNullOrWhiteSpace(oldAccount.Key) Then
            MsgBox("Error: New password is the same as the old!")
        ElseIf Not Newpass.Text.Length >= securePassLength Then
            MsgBox("Error: Password is not at secure length!")
        End If

        If Not Newpass.Text = ConfirmNewpass.Text And Not String.IsNullOrWhiteSpace(Newpass.Text) And Not String.IsNullOrWhiteSpace(ConfirmNewpass.Text) Then
            MsgBox("Error: New password not confirmed!")
        End If

        If accountInUse.Contains(oldAccount) And Newpass.Text = ConfirmNewpass.Text And Not Newpass.Text = passLog And Not ConfirmNewpass.Text = passLog And Not String.IsNullOrWhiteSpace(Newpass.Text) And Not String.IsNullOrWhiteSpace(ConfirmNewpass.Text) And Newpass.Text.Length >= securePassLength Then
            Dim writer As New StreamWriter("Accounts.txt", False)
            Dim writer2 As New StreamWriter("CurrentUser.txt", False)
            For Each account As KeyValuePair(Of String, String) In accountList
                If account.Key = oldAccount.Key Then
                    newAccountList.Add(New KeyValuePair(Of String, String)(Newpass.Text, account.Value))
                    writer2.WriteLine(account.Value)
                    writer2.WriteLine(Newpass.Text)
                Else
                    newAccountList.Add(New KeyValuePair(Of String, String)(account.Key, account.Value))
                End If
            Next
            writer2.Close()
            For Each newAcc As KeyValuePair(Of String, String) In newAccountList
                writer.WriteLine(newAcc.Value)
                writer.WriteLine(newAcc.Key)
            Next
            writer.Close()
            MsgBox("Password changed!")
            Me.Close()
        End If


    End Sub
    Private Sub Newpass_TextChanged_1(sender As Object, e As EventArgs) Handles Newpass.TextChanged
        If Not ConfirmNewpass.Text = Newpass.Text Then
            Confirmation.Text = "New password not confirmed"
        Else
            Confirmation.Text = ""
        End If

        If Newpass.Text.Length >= securePassLength Then
            SecurePass.Text = "Secure length"
        ElseIf Newpass.Text.Length >= 1 And Newpass.Text.Length < securePassLength Then
            SecurePass.Text = "Not at secure length"
        ElseIf Newpass.Text.Length = 0 Then
            SecurePass.Text = ""
        End If
    End Sub

    Private Sub ConfirmNewpass_TextChanged(sender As Object, e As EventArgs) Handles ConfirmNewpass.TextChanged
        If Not ConfirmNewpass.Text = Newpass.Text Then
            Confirmation.Text = "New password not confirmed"
        Else
            Confirmation.Text = ""
        End If
    End Sub
End Class